Đề tài: Quản lý Quán Coffee

=== BHS COFFEE ===
1. Nguyễn Văn Bảy	MSSV: 1751012088
2. Lê Thị Mỹ Hạnh	MSSV: 1751012016
3. Nguyễn Thanh Sang	MSSV: 1751012057

Mô tả ứng dụng:

**Bước 01**
- Đầu tiên, người dùng cần có một tài khoản để đăng nhập vào hệ thống. Tài khoản này được lưu trữ, cập nhật trực tiếp ở cơ sở dữ liệu. Ứng dụng không có chức năng quản lý tài khoản. Muốn cập nhật tài khoản phải vào SQL Server Management.

- Tài khoản demo có sẵn trong database có thể test là:
> Tên đăng nhập: baynv
> Mật khẩu: 123456

**Bước 02**
- Sau khi đăng nhập thành công, người dùng sẽ được nhìn thấy giao diện Bán hàng.
+ Ở thanh công cụ phía trên, người dùng có thể nhìn thấy Menu hiển thị tên đăng nhập, nhấn vào đó sẽ hiện ra nút Đăng xuất.
+ Ngay cạnh là thời gian Last login của tài khoản (lúc đăng nhập).
+ Phía bên phải cùng là nút **Thoát**, nhấn vào đây nếu bạn không muốn đăng xuất mà đóng ngay ứng dụng.

+ Ở giao diện chính phần thân lại gồm hai tab chức năng: Quản lý đồ uống, Quản lý bán hàng.


=== Ở tab Quản lý đồ uống ===
+ Người dùng sẽ nhìn thấy danh sách đồ uống hiện tại có trong cơ sở dữ liệu.
+ Để xem và cập nhật thông tin, người dùng nhấn chọn vào bất kỳ hàng nào trong danh sách, thông tin của đồ uống tương ứng hiện ra ở bảng thông tin bên phải. Lúc này, người dùng dựa vào bảng thông tin bên phải, có thể sửa các trường: **Tên đồ uống**, **Giá bán** và **Trạng thái** (cung cấp), sau đó nhấn **Lưu lại** để lưu thay đổi của đồ uống (nếu có). **Mã đồ uống** là không cho phép thay đổi, **Hình ảnh** sản phẩm có thể thay đổi bằng cách trực tiếp lưu đè lên file ảnh cũ đúng tên là **<mã đồ uống>.png** trong folder **Resources\DoUong**.

+ Để thêm mới một đồ uống, nhấn vào **Tạo mới**, chọn và lưu hình ảnh với tên **<mã đồ uống mới>.png** trong folder **Resources\DoUong**, nhập các thông tin **Mã sản phẩm**, **Tên sản phẩm**, **Giá sản phẩm**, **Trạng thái cung cấp**, sau đó nhấn **Lưu lại** để thêm hàng dữ liệu vào cơ sở dữ liệu.

+ Để xóa một đồ uống, chọn đến hàng đồ uống cần xóa, sau đó nhấn **Xóa**.


== Ở tab Quản lý bán hàng ==
+ Người dùng sẽ nhìn thấy tất cả đồ uống hiện tại có trong cơ sở dữ liệu.
+ Để thêm đồ uống vào **Hóa đơn bán hàng**, nhấn **+** ở góc dưới phải mỗi Đồ uống.
+ Để xóa tất cả đồ uống đã chọn trong **Hóa đơn bán hàng**, nhấn **Đặt lại**.
+ Nếu đã hoàn tất chọn các đồ uống vào hóa đơn, nhấn **In hóa đơn** để xem trước bản in. Sau đó, kiểm tra lại thông tin ở giao diện hiện lên, rồi nhấn **In hóa đơn** (ở giao diện hiện tại) để lưu hóa đơn thành file .pdf.
