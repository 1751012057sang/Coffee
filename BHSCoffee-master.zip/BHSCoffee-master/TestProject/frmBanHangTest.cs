﻿using BHSCoffeeApp;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    
    
    /// <summary>
    ///This is a test class for frmBanHangTest and is intended
    ///to contain all frmBanHangTest Unit Tests
    ///</summary>
    [TestClass()]
    public class frmBanHangTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /*===================================================*/
        /*============= TEST CHỨC NĂNG TÌM KIẾM =============*/
        /*===================================================*/
        // Test Loại tìm kiếm bỏ rỗng
        [TestMethod()]
        public void testLoaiTimKiemRong()
        {
            frmBanHang target = new frmBanHang("username");
            string kw = string.Empty; // Ô từ khóa nhập tùy thích
            string loaiTK = string.Empty; // Ô loại tìm kiếm rỗng
            bool expected = false;
            bool actual;
            actual = target.timKiem(kw, loaiTK);
            Assert.AreEqual(expected, actual);
        }

        // Test Loại tìm kiếm sai
        [TestMethod()]
        public void testLoaiTimKiemSai()
        {
            frmBanHang target = new frmBanHang("username");
            string kw = string.Empty;
            string loaiTK = "NhaCC";
            bool expected = false;
            bool actual;
            actual = target.timKiem(kw, loaiTK);
            Assert.AreEqual(expected, actual);
        }

        // Test Không nhập từ khóa
        [TestMethod()]
        public void testKhongNhapTuKhoa()
        {
            frmBanHang target = new frmBanHang("username");
            string kw = string.Empty;
            string loaiTK = "TenDoUong";
            bool expected = false;
            bool actual;
            actual = target.timKiem(kw, loaiTK);
            Assert.AreEqual(expected, actual);
        }

        // Test Từ khóa không khớp
        [TestMethod()]
        public void testTuKhoaKhongKhop()
        {
            frmBanHang target = new frmBanHang("username");
            string kw = "Sinh tố";
            string loaiTK = "TenDoUong";
            bool expected = false;
            bool actual;
            actual = target.timKiem(kw, loaiTK);
            Assert.AreEqual(expected, actual);
        }

        // Test tìm kiếm có kết quả bình thường
        [TestMethod()]
        public void testTimKiemBinhThuong()
        {
            frmBanHang target = new frmBanHang("username");
            string kw = "cà phê";
            string loaiTK = "TenDoUong";
            bool expected = false;
            bool actual;
            actual = target.timKiem(kw, loaiTK);
            Assert.AreEqual(expected, actual);
        }

        /*===================================================*/
        /*============= TEST CHỨC NĂNG CẬP NHẬT =============*/
        /*===================================================*/

        // Check nút Lưu lại một sản phẩm nhưng dữ liệu cập nhật rỗng
        [TestMethod()]
        public void testDLCapNhatRong()
        {
            frmBanHang target = new frmBanHang("username");
            string MaDoUong = String.Empty;
            string TenDoUong = String.Empty;
            string GiaDoUong = String.Empty;
            bool expected = false;
            bool actual;
            actual = target.capNhatDoUong(MaDoUong, TenDoUong, GiaDoUong);
            Assert.AreEqual(expected, actual);
        }

        // Check nút Lưu lại một sản phẩm nhưng trường nhập Giá đồ uống sai định dạng (nhập ký tự khác số)
        [TestMethod()]
        public void testGiaKhongPhaiSo()
        {
            frmBanHang target = new frmBanHang("username");
            string MaDoUong = "cf06";
            string TenDoUong = "HighLand Coffee";
            string GiaDoUong = "mienphi";
            bool expected = false;
            bool actual;
            actual = target.capNhatDoUong(MaDoUong, TenDoUong, GiaDoUong);
            Assert.AreEqual(expected, actual);
        }

        // Check nút Lưu lại một sản phẩm nhưng trường nhập Giá đồ uống âm
        [TestMethod()]
        public void testGiaAm()
        {
            frmBanHang target = new frmBanHang("username");
            string MaDoUong = "cf06";
            string TenDoUong = "HighLand Coffee";
            string GiaDoUong = "-1";
            bool expected = false;
            bool actual;
            actual = target.capNhatDoUong(MaDoUong, TenDoUong, GiaDoUong);
            Assert.AreEqual(expected, actual);
        }

        // Check nút Lưu lại một sản phẩm nhưng trường nhập Giá đồ uống quá lớn
        [TestMethod()]
        public void testGiaOverLoad()
        {
            frmBanHang target = new frmBanHang("username");
            string MaDoUong = "cf06";
            string TenDoUong = "HighLand Coffee";
            string GiaDoUong = "9999999999";
            bool expected = false;
            bool actual;
            actual = target.capNhatDoUong(MaDoUong, TenDoUong, GiaDoUong);
            Assert.AreEqual(expected, actual);
        }

        // Check nút Lưu lại một sản phẩm có thông tin đúng và đầy đủ, nhưng Mã đồ uống trùng với một đồ uống đã có
        // <=> Sửa thông tin đồ uống hiện đã có
        [TestMethod()]
        public void testTaoMoiTrungMa()
        {
            frmBanHang target = new frmBanHang("username");
            string MaDoUong = "cf01";
            string TenDoUong = "HighLand Coffee";
            string GiaDoUong = "20000";
            bool expected = true;
            bool actual;
            actual = target.capNhatDoUong(MaDoUong, TenDoUong, GiaDoUong);
            Assert.AreEqual(expected, actual);
        }

        // Check nút Lưu lại một sản phẩm có thông tin đúng và đầy đủ
        [TestMethod()]
        public void testTaoMoiBinhThuong()
        {
            frmBanHang target = new frmBanHang("username");
            string MaDoUong = "cf06";
            string TenDoUong = "HighLand Coffee";
            string GiaDoUong = "20000";
            bool expected = true;
            bool actual;
            actual = target.capNhatDoUong(MaDoUong, TenDoUong, GiaDoUong);
            Assert.AreEqual(expected, actual);
        }
        //Test chuc nang tinh tien
        [TestMethod]
        public void TestTinhTien()
        {
            frmBanHang target = new frmBanHang("username");
            int expected = 40000;
            int actual;
            int giaMon1 = 15000;
            int giaMon2 = 25000;
            actual = target.tinhTien(giaMon1);
            actual = target.tinhTien(giaMon2);
            Assert.AreEqual(expected, actual);
        }

    }
}
