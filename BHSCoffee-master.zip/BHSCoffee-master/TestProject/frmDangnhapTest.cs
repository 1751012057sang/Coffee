﻿using BHSCoffeeApp;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    /// <summary>
    ///This is a test class for frmDangnhapTest and is intended
    ///to contain all frmDangnhapTest Unit Tests
    ///</summary>
    [TestClass()]
    public class frmDangnhapTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        /// Test bo trong 2 o du lieu
        ///</summary>
        [TestMethod()]
        public void TestKhongNhap()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = string.Empty; 
            string mk = string.Empty;
            bool expected = false;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Test ten dung, pass bo trong
        ///</summary>
        [TestMethod()]
        public void TestKhongMK()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = "baynv";
            string mk = string.Empty;
            bool expected = false;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Test ten bo trong, pass dung
        ///</summary>
        [TestMethod()]
        public void TestKhongTen()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = string.Empty;
            string mk = "123456";
            bool expected = false;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Test ten dung, pass sai
        ///</summary>
        [TestMethod()]
        public void TestTenDungPassSai()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = "baynv";
            string mk = "wrong_pass";
            bool expected = false;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Test ten sai, pass dung
        ///</summary>
        [TestMethod()]
        public void TestTenSaiPassDung()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = "wrong_username";
            string mk = "123456";
            bool expected = false;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Test ten sai, pass sai
        ///</summary>
        [TestMethod()]
        public void TestTenSaiPassSai()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = "wrong_username";
            string mk = "wrong_pass";
            bool expected = false;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Test ten dung, pass dung
        ///</summary>
        [TestMethod()]
        public void TestTenDungPassDung()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = "baynv";
            string mk = "123456";
            bool expected = true;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Test ten qua dai hoac mat khau qua dai
        ///</summary>
        [TestMethod()]
        public void TestMatKhauQuaDai()
        {
            frmDangnhap target = new frmDangnhap();
            string ten = "baynv";
            string mk = "12345687301726923786";
            bool expected = false;
            bool actual;
            actual = target.DangNhap(ten, mk);
            Assert.AreEqual(expected, actual);
        }
    }
}
