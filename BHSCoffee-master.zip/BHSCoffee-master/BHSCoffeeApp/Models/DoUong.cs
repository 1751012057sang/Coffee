﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BHSCoffeeApp
{
    class DoUong
    {
        string ma_douong;
        string ten_douong;
        int don_gia;
        bool trang_thai;

        // Cac phuong thuc /getter setter
        public string MaDoUong
        {
            get { return ma_douong; }
            set { ma_douong = value; }
        }

        public string TenDoUong
        {
            get { return ten_douong; }
            set { ten_douong = value; }
        }

        public int DonGia
        {
            get { return don_gia; }
            set { don_gia = value; }
        }

        public bool TrangThai
        {
            get { return trang_thai; }
            set { trang_thai = value; }
        }
    }
}