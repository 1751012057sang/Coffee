﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BHSCoffeeApp
{
    class TaiKhoan
    {
        string tendn;
        string mk;

        // Phuong thuc khoi tao  day du tham so
        public TaiKhoan(string tendn, string mk)
        {
            this.tendn = tendn;
            this.mk = mk;
        }

        // Cac phuong thuc getter setter
        public string TenDangNhap
        {
            get { return tendn; }
            set { tendn = value; }
        }

        public string MatKhau
        {
            get { return mk; }
            set { mk = value; }
        }
    }
}
