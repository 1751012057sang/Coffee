﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BHSCoffeeApp
{
    public partial class frmDangnhap : Form
    {
        static string connection = @"Data Source=JASON\SQLEXPRESS;Initial Catalog=bhsdb;Integrated Security=True";
        
        public frmDangnhap()
        {
            InitializeComponent();
        }

        // phuong thuc kiem tra rong
        private Boolean isEmpty(string txt)
        {
            if (txt.Trim() == "")
                return true;
            return false;
        }

        // phuong thuc dang nhap
        public bool DangNhap(string ten, string mk)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                try
                {
                    string ten1;
                    string mk1;
                    ten1 = checked(ten);
                    mk1 = checked(mk);
                    if (isEmpty(ten) || isEmpty(mk))
                    {
                        MessageBox.Show("Vui lòng nhập đủ thông tin tài khoản!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false; // khong dang nhap duoc do thieu thong tin tai khoan
                    }
                    else
                    {
                        TaiKhoan tk = new TaiKhoan(ten, mk);

                        // tien hanh truy xuat csdl de dang nhap
                        string queryLogin = "SELECT * FROM TaiKhoan WHERE TenDN = '" + tk.TenDangNhap + "' AND MatKhau = '" + tk.MatKhau + "'";
                        SqlDataAdapter sda = new SqlDataAdapter(queryLogin, con);
                        DataTable dtb1 = new DataTable();
                        sda.Fill(dtb1);

                        if (dtb1.Rows.Count == 1)
                        {
                            int role = int.Parse(dtb1.Rows[0]["ChucNang"].ToString());
                            MessageBox.Show("Đăng nhập thành công!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            return true; // dang nhap thanh cong
                        }
                        else
                        {
                            MessageBox.Show("Tài khoản hoặc mật khẩu không đúng!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            return false; // khong dang nhap duoc do sai thong tin tai khoan
                        }
                    }
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Tài khoản hoặc mật khẩu quá dài!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
        }

        //
        // XU LY CAC BUTTON TREN FORM
        //

        // Button Dang Nhap
        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            string ten = txttendn.Text.Trim();
            string mk = txtmk.Text.Trim();
            bool kq = DangNhap(ten, mk);

            // Kiem tra tai khoan thanh cong, dang nhap vao ung dung
            if (kq == true)
            {
                Form f = new frmBanHang(txttendn.Text.Trim());
                this.Hide();
                f.Show();
            }
        }
    }
}
