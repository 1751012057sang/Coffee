﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Printing;
using System.IO;

namespace BHSCoffeeApp
{
    public partial class frmBanHang : Form
    {
        static string connection = @"Data Source=JASON\SQLEXPRESS;Initial Catalog=bhsdb;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);

        string path = Application.StartupPath;

        List<DoUong> dsDoUong;

        int count = 0, sumPrice = 0; // Đếm số lượng đồ uống chọn, tính tổng giá của lượng đồ uống đó

        public frmBanHang()
        {
            InitializeComponent();
        }

        // khởi tạo form có truyền dữ liệu tên tài khoản đăng nhập
        public frmBanHang(string acc)
        {
            InitializeComponent();
            account.Text = acc;
        }

        public int tinhTien(int gia)
        {
            sumPrice += gia;
            return sumPrice;
        }
        // Kết nối và hiển thị cơ sở dữ liệu lên form khi form được mở lên
        private void frmBanHang_Load(object sender, EventArgs e)
        {
            // Hiển thị thời gian last login
            currentTime.Text = DateTime.Now.ToString("HH:mm tt");

            try
            {
                con.Open(); // Kết nối csdl

                SqlDataAdapter sqlData = new SqlDataAdapter("SELECT * FROM DoUong", con);
                DataTable dtb1 = new DataTable();
                sqlData.Fill(dtb1);

                /**
                 * Thêm các cột vào hóa đơn
                 * */
                listSellItems.Columns.Add("STT", 50);
                listSellItems.Columns.Add("Tên Đồ uống", 150);
                listSellItems.Columns.Add("Đơn giá", 100);

                dgvDoUong.DataSource = dtb1; // hiển thị danh sách đồ uống lên dgvDoUong
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Hiển thị danh sách đồ uống từ csdl lên listview
        private void loadDSDoUong()
        {
            DataTable dtb1 = new DataTable();
            SqlDataAdapter sqlData = new SqlDataAdapter("SELECT * FROM DoUong", con);
            sqlData.Fill(dtb1);

            dgvDoUong.DataSource = dtb1;
        }

        // Thêm mới một đồ uống vào flpDoUong (trong form_load)
        private void addNewDrink(DoUong du)
        {
            Label lblTenDoUong = new Label();
            Label lblGiaDoUong = new Label();
            PictureBox pbDoUong = new PictureBox();
            Button btnAddToCart = new Button();
            GroupBox grBox = new GroupBox();

            grBox.Controls.Add(lblTenDoUong);
            grBox.Controls.Add(lblGiaDoUong);
            grBox.Controls.Add(pbDoUong);
            grBox.Controls.Add(btnAddToCart);

            // 
            // grBox
            //
            grBox.Size = new Size(90, 120);
            grBox.BackColor = Color.DeepSkyBlue;

            // 
            // lblTenDoUong
            //
            lblTenDoUong.Size = new Size(90, 15);
            lblTenDoUong.Text = du.TenDoUong;
            lblTenDoUong.Location = new Point(0, 10);
            lblTenDoUong.Font = new Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lblTenDoUong.TextAlign = ContentAlignment.MiddleCenter;

            // 
            // lblGiaDoUong
            //
            lblGiaDoUong.Size = new Size(58, 15);
            lblGiaDoUong.Text = du.DonGia + "đ";
            lblGiaDoUong.Location = new Point(2, 96);
            lblTenDoUong.BackColor = Color.Transparent;

            // 
            // btnAddToCart
            //
            btnAddToCart.Size = new Size(30, 25);
            btnAddToCart.Text = "+";
            btnAddToCart.Location = new Point(60, 95);
            //btnAddToCart.Click += new System.EventHandler(btnAddToCart_Click);
            btnAddToCart.Click += (object sender, EventArgs e) =>
            {
                int giaBan = 0;
                string[] arr = new string[4];
                count++;
                arr[0] = (count).ToString();
                arr[1] = lblTenDoUong.Text;
                arr[2] = lblGiaDoUong.Text;
                giaBan = int.Parse(lblGiaDoUong.Text.Substring(0, lblGiaDoUong.Text.Length - 1));
                txtSum.Text = tinhTien(giaBan).ToString();

                ListViewItem item = new ListViewItem(arr);
                listSellItems.Items.Add(item);
            };

            // 
            // pbDoUong
            //
            pbDoUong.Size = new Size(60, 60);
            pbDoUong.Image = Image.FromFile(path.Substring(0, path.Length - 9) + @"Resources\DoUong\" + du.MaDoUong + ".png");
            pbDoUong.SizeMode = PictureBoxSizeMode.Zoom;
            pbDoUong.Location = new Point(15, 30);
            this.flpDoUong.Controls.Add(grBox);
        }
        
        // Xử lý hiển thị thông tin lên bảng bên phải khi chọn từng hàng trong danh sách
        private void dgvDoUong_SelectionChanged(object sender, EventArgs e)
        {
            txtMaDoUong.Enabled = false;
            btnChonHinh.Visible = false;

            try
            {
                int idx = dgvDoUong.CurrentRow.Index;
                string maDoUong = (dgvDoUong.Rows[idx].Cells[0].Value).ToString();
                txtMaDoUong.Text = maDoUong;
                txtTenDoUong.Text = (dgvDoUong.Rows[idx].Cells[1].Value).ToString();

                txtGia.Text = (dgvDoUong.Rows[idx].Cells[2].Value).ToString();
                
                pbDoUong.Image = Image.FromFile(path.Substring(0, path.Length - 9) + @"Resources\DoUong\" + maDoUong + ".png");
                
                if (Convert.ToInt32(dgvDoUong.Rows[idx].Cells[3].Value) == 1)
                {
                    rdConHang.Checked = true;
                    rdHetHang.Checked = false;
                }
                else
                {
                    rdConHang.Checked = false;
                    rdHetHang.Checked = true;
                }
            }

            catch (InvalidCastException)
            {
                MessageBox.Show("InvalidCastException");
            }
        }

        // Tìm kiếm đồ uống theo từ khóa và loại tìm kiếm được chọn trên form
        public bool timKiem(string tukhoa, string loaiTimKiem)
        {
            if (loaiTimKiem == "" || (loaiTimKiem != "TenDoUong" && loaiTimKiem != "MaDoUong"))
            {
                MessageBox.Show("Vui lòng chọn loại tìm kiếm hợp lệ!");
                return false;
            }
            else
            {
                if (txtKW.Text.Trim() != String.Empty)
                {
                    SqlDataAdapter sqlData = new SqlDataAdapter("SELECT * FROM DoUong WHERE " + loaiTimKiem + " LIKE N'%" + txtKW.Text.Trim() + "%'", con);
                    DataTable dtb1 = new DataTable();
                    sqlData.Fill(dtb1);

                    if (dtb1.Rows.Count == 0)
                    {
                        MessageBox.Show("Không tìm thấy sản phẩm nào khớp với từ khóa!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }

                    dgvDoUong.DataSource = dtb1;

                    return true;
                }
                else
                {
                    MessageBox.Show("Vui lòng nhập từ khóa cần tìm!");
                    return false;
                }
            }
        }

        // Bắt sự kiện click btnTimKiem
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            timKiem(txtKW.Text, cbLoaiTimKiem.Text);
        }

        // Bắt sự kiện click btnTaoMoiDoUong
        private void btnTaoMoiDoUong_Click(object sender, EventArgs e)
        {
            txtMaDoUong.Enabled = true;
            txtMaDoUong.Text = txtTenDoUong.Text = txtGia.Text = "";
            rdConHang.Checked = true;
            pbDoUong.Image = null;
            btnChonHinh.Visible = true;
        }

        // Chọn hình ảnh (cho đồ uống mới)
        private void chonHinh()
        {
            Image picDoUong;
            string fname = path.Substring(0, path.Length - 9) + @"Resources\DoUong\" + txtMaDoUong.Text + ".png";
            OpenFileDialog open = new OpenFileDialog();

            open.Filter = "(*.png) | *.png";

            if (open.ShowDialog() == DialogResult.OK)
            {
                picDoUong = Image.FromFile(open.FileName);

                SaveFileDialog fSave = new SaveFileDialog();
                fSave.InitialDirectory = path.Substring(0, path.Length - 9) + @"Resources\DoUong\";
                fSave.Filter = "(*.png) | *.png";
                fSave.FileName = txtMaDoUong.Text + ".png";
                if (fSave.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        picDoUong.Save(fSave.FileName);
                        pbDoUong.Image = Image.FromFile(path.Substring(0, path.Length - 9) + @"Resources\DoUong\" + txtMaDoUong.Text.Trim() + ".png");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
        
        // Xử lý click btnChonHinh
        private void btnChonHinh_Click(object sender, EventArgs e)
        {
            chonHinh();
        }

        // Kiểm tra dữ liệu và cập nhật đồ uống
        public bool capNhatDoUong(string MaDoUong, string TenDoUong, string GiaDoUong)
        {
            if (MaDoUong.Trim() == "" || TenDoUong.Trim() == "" || GiaDoUong.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return false;
            }
            else
            {
                try
                {
                    if (GiaDoUong.Trim().Length <= 7) // Giá đồ uống đắt nhất có thể là 9999999 đ
                    {
                        int dongia = int.Parse(GiaDoUong.Trim());
                        if (dongia < 0)
                            throw new Exception("Dữ liệu đơn giá nhập không được âm!");
                    }
                    else
                        throw new Exception("Giá đồ uống không thể quá lớn!");
                    
                    /* ====================================== */
                    //       CẬP NHẬT THÔNG TIN ĐỒ UỐNG       //
                    /* ====================================== */

                    SqlDataAdapter sqlData = new SqlDataAdapter("SELECT * FROM DoUong WHERE MaDoUong = '" + txtMaDoUong.Text.Trim() + "'", con);
                    DataTable dtb1 = new DataTable();
                    sqlData.Fill(dtb1);

                    // Lệnh SQL cập nhật dữ liệu đã có trong csdl
                    string cmd = "UPDATE DoUong SET MaDoUong = N'" + txtMaDoUong.Text.Trim() +
                        "', TenDoUong = N'" + txtTenDoUong.Text.Trim() +
                        "', DonGia = N'" + txtGia.Text.Trim() + "', TrangThai = '" +
                        (rdConHang.Checked == true ? 1 : 0) + "' WHERE MaDoUong = N'" + txtMaDoUong.Text.Trim() +
                        "'";

                    // Lệnh SQL thêm mới một hàng dữ liệu
                    string cmdAdd = "INSERT INTO DoUong (MaDoUong, TenDoUong, DonGia, TrangThai) VALUES (N'" + txtMaDoUong.Text.Trim() + "', N'" + txtTenDoUong.Text.Trim() + "', N'" + txtGia.Text.Trim() + "', " + (rdConHang.Checked == true ? 1 : 0) + ")";

                    // Thiết lập SQL cmd
                    SqlCommand saveRecord = new SqlCommand();
                    saveRecord.Connection = con;
                    saveRecord.CommandType = CommandType.Text;

                    if (dtb1.Rows.Count > 0)
                    {
                        if (MessageBox.Show("Lưu thay đổi cho sản phẩm hiện có?", "Xác nhận",
                            MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                        {
                            saveRecord.CommandText = cmd;
                            saveRecord.ExecuteNonQuery();
                            MessageBox.Show("Lưu đồ uống thành công!");
                        }
                    }
                    else
                    {
                        saveRecord.CommandText = cmdAdd;

                        // Create new pic for new product
                        if (pbDoUong.Image == null)
                        {
                            MessageBox.Show("Chọn hình ảnh cho đồ uống mới!");
                            chonHinh();
                        }
                        saveRecord.ExecuteNonQuery();
                        MessageBox.Show("Lưu đồ uống thành công!");
                    }
                    loadDSDoUong();

                    /* ====================================== */
                    return true;
                }
                catch (FormatException)
                {
                    MessageBox.Show("Dữ liệu đơn giá nhập không hợp lệ!");
                    return false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;
                }
            }
        }

        // Xử lý sự kiện click btnLuuDoUong
        private void btnLuuDoUong_Click(object sender, EventArgs e)
        {
            capNhatDoUong(txtMaDoUong.Text.Trim(), txtTenDoUong.Text.Trim(), txtGia.Text.Trim());
        }
            
        // Xử lý click btnReset
        private void btnReset_Click(object sender, EventArgs e)
        {
            count = 0;
            txtSum.Text = "0";
            listSellItems.Clear();
            listSellItems.Columns.Add("STT", 50);
            listSellItems.Columns.Add("Tên Đồ uống", 150);
            listSellItems.Columns.Add("Đơn giá", 100);
        }

        // Xử lý click btnXoaDoUong
        private void btnXoaDoUong_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Xóa sản phẩm " + txtMaDoUong.Text + "?", "Xác nhận", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                string cmd = "DELETE FROM DoUong WHERE MaDoUong = N'" + txtMaDoUong.Text + "'";

                SqlCommand deleteRecord = new SqlCommand();
                deleteRecord.Connection = con;
                deleteRecord.CommandType = CommandType.Text;
                deleteRecord.CommandText = cmd;

                deleteRecord.ExecuteNonQuery();
                loadDSDoUong();
            }
        }

        // Xử lý click btnThemHoaDon
        private void btnThemHoaDon_Click(object sender, EventArgs e)
        {
            int dem = listSellItems.Items.Count;
            if (dem > 0)
            {
                string[] item = new string[dem];
                string delimiter = ",";
                for (int i = 0; i < item.Length; i++)
                {
                    string str = String.Empty;
                    str += listSellItems.Items[i].Text + delimiter;
                    str += listSellItems.Items[i].SubItems[1].Text + delimiter;
                    str += listSellItems.Items[i].SubItems[2].Text + delimiter;
                    item[i] = str;
                }
                Form f = new frmHoaDon(account.Text, item);
                this.Hide();

                f.Show();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn đồ uống!");
            }
        }

        // Xử lý nút Thoát trên form
        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn thoát?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                Application.Exit();
        }

        // Xử lý nút Đăng xuất trong cửa sổ menu của account đăng nhập
        private void logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f = new frmDangnhap();
            f.Show();
        }

        // Làm mới đồ uống hiển thị lên flpDoUong
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 1)
            {
                SqlDataAdapter sqlData = new SqlDataAdapter("SELECT * FROM DoUong", con);
                DataTable dtb1 = new DataTable();
                sqlData.Fill(dtb1);

                dsDoUong = new List<DoUong>(); // đưa thông tin cơ sở dữ liệu vào List để quản lý

                for (int i = 0; i < dtb1.Rows.Count; i++)
                {
                    DoUong doUong = new DoUong();
                    doUong.MaDoUong = dtb1.Rows[i]["MaDoUong"].ToString();
                    doUong.TenDoUong = dtb1.Rows[i]["TenDoUong"].ToString();
                    doUong.DonGia = Convert.ToInt32(dtb1.Rows[i]["DonGia"]);
                    doUong.TrangThai = ((Convert.ToInt32(dtb1.Rows[i]["TrangThai"]) == 1) ? true : false);

                    /* =========== THÊM ĐỒ UỐNG VÀO DANH SÁCH CHỌN ========= */
                    addNewDrink(doUong);
                    /* =============================== */
                }
            }
            else
            {
                flpDoUong.Controls.Clear();
            }
        }
    }
}
