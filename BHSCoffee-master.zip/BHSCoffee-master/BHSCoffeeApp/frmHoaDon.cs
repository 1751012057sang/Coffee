﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BHSCoffeeApp
{
    public partial class frmHoaDon : Form
    {
        public frmHoaDon()
        {
            InitializeComponent();
        }

        public frmHoaDon(string tenNV, string []list)
        {
            InitializeComponent();

            int sumPrice = 0;

            for (int i = 0; i < list.Length; i++)
            {
                string[] row = list[i].Split(new char[] { (',') });

                sumPrice += int.Parse(row[2].Substring(0, row[2].Length - 1));

                ListViewItem item = new ListViewItem(row);
                listSellItems.Items.Add(item);
            }

            lblSum.Text = sumPrice.ToString() + "đ";

            lblMaNV.Text = tenNV;

            lblNgay.Text = "Ngày: " + DateTime.Now.ToString("dd/MM/yyyy");
            lblGio.Text = "Giờ: " + DateTime.Now.ToString("HH:mm tt");
        }

        private void frmHoaDon_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form f = new frmBanHang(lblMaNV.Text);
            this.Hide();
            f.Show();
        }

        Bitmap bmp;

        private void btnIn_Click(object sender, EventArgs e)
        {
            btnIn.Visible = false;

            Graphics g = this.CreateGraphics();
            bmp = new Bitmap(this.Size.Width, this.Size.Height, g);

            Graphics mg = Graphics.FromImage(bmp);

            mg.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, this.Size);
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bmp, 0, 0);
        }
    }
}
