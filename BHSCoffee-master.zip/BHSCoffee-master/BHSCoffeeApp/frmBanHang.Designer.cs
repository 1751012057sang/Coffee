﻿namespace BHSCoffeeApp
{
    partial class frmBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.currentTime = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.account = new System.Windows.Forms.ToolStripMenuItem();
            this.logout = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dgvDoUong = new System.Windows.Forms.DataGridView();
            this.MaDoUong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenDoUong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TrangThai = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabDoUong = new System.Windows.Forms.TabPage();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.cbLoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtKW = new System.Windows.Forms.TextBox();
            this.grTaoMoiDoUong = new System.Windows.Forms.GroupBox();
            this.btnChonHinh = new System.Windows.Forms.Button();
            this.txtTenDoUong = new System.Windows.Forms.TextBox();
            this.pbDoUong = new System.Windows.Forms.PictureBox();
            this.txtMaDoUong = new System.Windows.Forms.TextBox();
            this.rdHetHang = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rdConHang = new System.Windows.Forms.RadioButton();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnTaoMoiDoUong = new System.Windows.Forms.Button();
            this.btnLuuDoUong = new System.Windows.Forms.Button();
            this.btnXoaDoUong = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabBanHang = new System.Windows.Forms.TabPage();
            this.pnHoaDon = new System.Windows.Forms.Panel();
            this.listSellItems = new System.Windows.Forms.ListView();
            this.btnThemHoaDon = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSum = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.flpDoUong = new System.Windows.Forms.FlowLayoutPanel();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoUong)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabDoUong.SuspendLayout();
            this.grTaoMoiDoUong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDoUong)).BeginInit();
            this.tabBanHang.SuspendLayout();
            this.pnHoaDon.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.currentTime);
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Controls.Add(this.menuStrip1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(799, 38);
            this.panel2.TabIndex = 0;
            // 
            // currentTime
            // 
            this.currentTime.AutoSize = true;
            this.currentTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentTime.Location = new System.Drawing.Point(280, 9);
            this.currentTime.Name = "currentTime";
            this.currentTime.Size = new System.Drawing.Size(68, 17);
            this.currentTime.TabIndex = 3;
            this.currentTime.Text = "00:00 PM";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Red;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Yellow;
            this.btnClose.Location = new System.Drawing.Point(725, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(67, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Thoát";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.account});
            this.menuStrip1.Location = new System.Drawing.Point(173, 5);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(87, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // account
            // 
            this.account.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logout});
            this.account.Name = "account";
            this.account.Size = new System.Drawing.Size(75, 21);
            this.account.Text = "Tài khoản";
            // 
            // logout
            // 
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(135, 22);
            this.logout.Text = "Đăng xuất";
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::BHSCoffeeApp.Properties.Resources.logo_transp;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(-85, -16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 69);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // dgvDoUong
            // 
            this.dgvDoUong.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDoUong.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDoUong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoUong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaDoUong,
            this.TenDoUong,
            this.DonGia,
            this.TrangThai});
            this.dgvDoUong.Location = new System.Drawing.Point(6, 56);
            this.dgvDoUong.Name = "dgvDoUong";
            this.dgvDoUong.Size = new System.Drawing.Size(447, 277);
            this.dgvDoUong.TabIndex = 6;
            this.dgvDoUong.SelectionChanged += new System.EventHandler(this.dgvDoUong_SelectionChanged);
            // 
            // MaDoUong
            // 
            this.MaDoUong.DataPropertyName = "MaDoUong";
            this.MaDoUong.HeaderText = "Mã Đồ Uống";
            this.MaDoUong.Name = "MaDoUong";
            this.MaDoUong.ReadOnly = true;
            this.MaDoUong.Width = 120;
            // 
            // TenDoUong
            // 
            this.TenDoUong.DataPropertyName = "TenDoUong";
            this.TenDoUong.HeaderText = "Tên Đồ Uống";
            this.TenDoUong.Name = "TenDoUong";
            this.TenDoUong.ReadOnly = true;
            this.TenDoUong.Width = 125;
            // 
            // DonGia
            // 
            this.DonGia.DataPropertyName = "DonGia";
            this.DonGia.HeaderText = "Đơn Giá";
            this.DonGia.Name = "DonGia";
            this.DonGia.ReadOnly = true;
            this.DonGia.Width = 80;
            // 
            // TrangThai
            // 
            this.TrangThai.DataPropertyName = "TrangThai";
            this.TrangThai.HeaderText = "Trạng Thái";
            this.TrangThai.Name = "TrangThai";
            this.TrangThai.ReadOnly = true;
            this.TrangThai.Width = 80;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabDoUong);
            this.tabControl1.Controls.Add(this.tabBanHang);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 38);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(799, 375);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabDoUong
            // 
            this.tabDoUong.BackColor = System.Drawing.Color.Teal;
            this.tabDoUong.Controls.Add(this.btnTimKiem);
            this.tabDoUong.Controls.Add(this.cbLoaiTimKiem);
            this.tabDoUong.Controls.Add(this.label1);
            this.tabDoUong.Controls.Add(this.txtKW);
            this.tabDoUong.Controls.Add(this.grTaoMoiDoUong);
            this.tabDoUong.Controls.Add(this.dgvDoUong);
            this.tabDoUong.Controls.Add(this.btnTaoMoiDoUong);
            this.tabDoUong.Controls.Add(this.btnLuuDoUong);
            this.tabDoUong.Controls.Add(this.btnXoaDoUong);
            this.tabDoUong.Controls.Add(this.label2);
            this.tabDoUong.Location = new System.Drawing.Point(4, 25);
            this.tabDoUong.Name = "tabDoUong";
            this.tabDoUong.Padding = new System.Windows.Forms.Padding(3);
            this.tabDoUong.Size = new System.Drawing.Size(791, 346);
            this.tabDoUong.TabIndex = 0;
            this.tabDoUong.Text = "QUẢN LÝ ĐỒ UỐNG";
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Location = new System.Drawing.Point(373, 24);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(79, 27);
            this.btnTimKiem.TabIndex = 2;
            this.btnTimKiem.Text = "Tìm kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = true;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // cbLoaiTimKiem
            // 
            this.cbLoaiTimKiem.DisplayMember = "TenDoUong";
            this.cbLoaiTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbLoaiTimKiem.FormattingEnabled = true;
            this.cbLoaiTimKiem.Items.AddRange(new object[] {
            "TenDoUong",
            "MaDoUong"});
            this.cbLoaiTimKiem.Location = new System.Drawing.Point(212, 25);
            this.cbLoaiTimKiem.Name = "cbLoaiTimKiem";
            this.cbLoaiTimKiem.Size = new System.Drawing.Size(153, 24);
            this.cbLoaiTimKiem.TabIndex = 1;
            this.cbLoaiTimKiem.Text = "TenDoUong";
            this.cbLoaiTimKiem.ValueMember = "TenDoUong";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nhập từ khóa tìm kiếm";
            // 
            // txtKW
            // 
            this.txtKW.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKW.Location = new System.Drawing.Point(6, 25);
            this.txtKW.Name = "txtKW";
            this.txtKW.Size = new System.Drawing.Size(197, 23);
            this.txtKW.TabIndex = 0;
            // 
            // grTaoMoiDoUong
            // 
            this.grTaoMoiDoUong.Controls.Add(this.btnChonHinh);
            this.grTaoMoiDoUong.Controls.Add(this.txtTenDoUong);
            this.grTaoMoiDoUong.Controls.Add(this.pbDoUong);
            this.grTaoMoiDoUong.Controls.Add(this.txtMaDoUong);
            this.grTaoMoiDoUong.Controls.Add(this.rdHetHang);
            this.grTaoMoiDoUong.Controls.Add(this.label4);
            this.grTaoMoiDoUong.Controls.Add(this.label3);
            this.grTaoMoiDoUong.Controls.Add(this.rdConHang);
            this.grTaoMoiDoUong.Controls.Add(this.txtGia);
            this.grTaoMoiDoUong.Controls.Add(this.label5);
            this.grTaoMoiDoUong.Controls.Add(this.label6);
            this.grTaoMoiDoUong.Controls.Add(this.label7);
            this.grTaoMoiDoUong.Location = new System.Drawing.Point(459, 0);
            this.grTaoMoiDoUong.Name = "grTaoMoiDoUong";
            this.grTaoMoiDoUong.Size = new System.Drawing.Size(325, 296);
            this.grTaoMoiDoUong.TabIndex = 6;
            this.grTaoMoiDoUong.TabStop = false;
            // 
            // btnChonHinh
            // 
            this.btnChonHinh.Location = new System.Drawing.Point(214, 112);
            this.btnChonHinh.Name = "btnChonHinh";
            this.btnChonHinh.Size = new System.Drawing.Size(73, 34);
            this.btnChonHinh.TabIndex = 5;
            this.btnChonHinh.Text = "Chọn";
            this.btnChonHinh.UseVisualStyleBackColor = true;
            this.btnChonHinh.Visible = false;
            this.btnChonHinh.Click += new System.EventHandler(this.btnChonHinh_Click);
            // 
            // txtTenDoUong
            // 
            this.txtTenDoUong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDoUong.Location = new System.Drawing.Point(116, 70);
            this.txtTenDoUong.Name = "txtTenDoUong";
            this.txtTenDoUong.Size = new System.Drawing.Size(173, 23);
            this.txtTenDoUong.TabIndex = 1;
            // 
            // pbDoUong
            // 
            this.pbDoUong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pbDoUong.Location = new System.Drawing.Point(116, 112);
            this.pbDoUong.Name = "pbDoUong";
            this.pbDoUong.Size = new System.Drawing.Size(92, 86);
            this.pbDoUong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDoUong.TabIndex = 4;
            this.pbDoUong.TabStop = false;
            // 
            // txtMaDoUong
            // 
            this.txtMaDoUong.Enabled = false;
            this.txtMaDoUong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDoUong.Location = new System.Drawing.Point(116, 35);
            this.txtMaDoUong.Name = "txtMaDoUong";
            this.txtMaDoUong.Size = new System.Drawing.Size(173, 23);
            this.txtMaDoUong.TabIndex = 0;
            // 
            // rdHetHang
            // 
            this.rdHetHang.AutoSize = true;
            this.rdHetHang.Location = new System.Drawing.Point(203, 256);
            this.rdHetHang.Name = "rdHetHang";
            this.rdHetHang.Size = new System.Drawing.Size(84, 21);
            this.rdHetHang.TabIndex = 4;
            this.rdHetHang.Text = "Hết hàng";
            this.rdHetHang.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(36, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tên đồ uống";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(36, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mã đồ uống";
            // 
            // rdConHang
            // 
            this.rdConHang.AutoSize = true;
            this.rdConHang.Checked = true;
            this.rdConHang.Location = new System.Drawing.Point(120, 256);
            this.rdConHang.Name = "rdConHang";
            this.rdConHang.Size = new System.Drawing.Size(70, 21);
            this.rdConHang.TabIndex = 3;
            this.rdConHang.TabStop = true;
            this.rdConHang.Text = "Có sẵn";
            this.rdConHang.UseVisualStyleBackColor = true;
            // 
            // txtGia
            // 
            this.txtGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGia.Location = new System.Drawing.Point(116, 218);
            this.txtGia.Name = "txtGia";
            this.txtGia.Size = new System.Drawing.Size(173, 23);
            this.txtGia.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(36, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Hình ảnh";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(37, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 26);
            this.label6.TabIndex = 1;
            this.label6.Text = "Trạng thái\r\ncung cấp";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(42, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Giá bán";
            // 
            // btnTaoMoiDoUong
            // 
            this.btnTaoMoiDoUong.Location = new System.Drawing.Point(471, 303);
            this.btnTaoMoiDoUong.Name = "btnTaoMoiDoUong";
            this.btnTaoMoiDoUong.Size = new System.Drawing.Size(102, 34);
            this.btnTaoMoiDoUong.TabIndex = 3;
            this.btnTaoMoiDoUong.Text = "Tạo mới";
            this.btnTaoMoiDoUong.UseVisualStyleBackColor = true;
            this.btnTaoMoiDoUong.Click += new System.EventHandler(this.btnTaoMoiDoUong_Click);
            // 
            // btnLuuDoUong
            // 
            this.btnLuuDoUong.Location = new System.Drawing.Point(574, 303);
            this.btnLuuDoUong.Name = "btnLuuDoUong";
            this.btnLuuDoUong.Size = new System.Drawing.Size(98, 34);
            this.btnLuuDoUong.TabIndex = 4;
            this.btnLuuDoUong.Text = "Lưu lại";
            this.btnLuuDoUong.UseVisualStyleBackColor = true;
            this.btnLuuDoUong.Click += new System.EventHandler(this.btnLuuDoUong_Click);
            // 
            // btnXoaDoUong
            // 
            this.btnXoaDoUong.Location = new System.Drawing.Point(673, 303);
            this.btnXoaDoUong.Name = "btnXoaDoUong";
            this.btnXoaDoUong.Size = new System.Drawing.Size(98, 34);
            this.btnXoaDoUong.TabIndex = 5;
            this.btnXoaDoUong.Text = "Xóa";
            this.btnXoaDoUong.UseVisualStyleBackColor = true;
            this.btnXoaDoUong.Click += new System.EventHandler(this.btnXoaDoUong_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(210, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tìm kiếm theo";
            // 
            // tabBanHang
            // 
            this.tabBanHang.BackColor = System.Drawing.Color.Teal;
            this.tabBanHang.Controls.Add(this.pnHoaDon);
            this.tabBanHang.Controls.Add(this.flpDoUong);
            this.tabBanHang.Location = new System.Drawing.Point(4, 25);
            this.tabBanHang.Name = "tabBanHang";
            this.tabBanHang.Size = new System.Drawing.Size(791, 346);
            this.tabBanHang.TabIndex = 1;
            this.tabBanHang.Text = "QUẢN LÝ BÁN HÀNG";
            // 
            // pnHoaDon
            // 
            this.pnHoaDon.Controls.Add(this.listSellItems);
            this.pnHoaDon.Controls.Add(this.btnThemHoaDon);
            this.pnHoaDon.Controls.Add(this.label10);
            this.pnHoaDon.Controls.Add(this.label8);
            this.pnHoaDon.Controls.Add(this.label9);
            this.pnHoaDon.Controls.Add(this.txtSum);
            this.pnHoaDon.Controls.Add(this.btnReset);
            this.pnHoaDon.Location = new System.Drawing.Point(517, 3);
            this.pnHoaDon.Name = "pnHoaDon";
            this.pnHoaDon.Size = new System.Drawing.Size(266, 335);
            this.pnHoaDon.TabIndex = 16;
            // 
            // listSellItems
            // 
            this.listSellItems.Location = new System.Drawing.Point(10, 46);
            this.listSellItems.Name = "listSellItems";
            this.listSellItems.Size = new System.Drawing.Size(249, 184);
            this.listSellItems.TabIndex = 14;
            this.listSellItems.UseCompatibleStateImageBehavior = false;
            this.listSellItems.View = System.Windows.Forms.View.Details;
            // 
            // btnThemHoaDon
            // 
            this.btnThemHoaDon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemHoaDon.ForeColor = System.Drawing.Color.White;
            this.btnThemHoaDon.Location = new System.Drawing.Point(157, 287);
            this.btnThemHoaDon.Name = "btnThemHoaDon";
            this.btnThemHoaDon.Size = new System.Drawing.Size(102, 34);
            this.btnThemHoaDon.TabIndex = 8;
            this.btnThemHoaDon.Text = "In hóa đơn";
            this.btnThemHoaDon.UseVisualStyleBackColor = true;
            this.btnThemHoaDon.Click += new System.EventHandler(this.btnThemHoaDon_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(225, 256);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "VNĐ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(8, 255);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Tổng cộng:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(51, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(172, 19);
            this.label9.TabIndex = 13;
            this.label9.Text = "HÓA ĐƠN BÁN HÀNG";
            // 
            // txtSum
            // 
            this.txtSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSum.Location = new System.Drawing.Point(76, 251);
            this.txtSum.Name = "txtSum";
            this.txtSum.ReadOnly = true;
            this.txtSum.Size = new System.Drawing.Size(147, 23);
            this.txtSum.TabIndex = 9;
            this.txtSum.Text = "0";
            this.txtSum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnReset
            // 
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.White;
            this.btnReset.Location = new System.Drawing.Point(52, 287);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(102, 34);
            this.btnReset.TabIndex = 11;
            this.btnReset.Text = "Đặt lại";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // flpDoUong
            // 
            this.flpDoUong.AutoScroll = true;
            this.flpDoUong.BackColor = System.Drawing.Color.Teal;
            this.flpDoUong.Dock = System.Windows.Forms.DockStyle.Left;
            this.flpDoUong.Location = new System.Drawing.Point(0, 0);
            this.flpDoUong.Name = "flpDoUong";
            this.flpDoUong.Size = new System.Drawing.Size(500, 346);
            this.flpDoUong.TabIndex = 15;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = "Hình Thu Nhỏ";
            this.dataGridViewImageColumn1.Image = global::BHSCoffeeApp.Properties.Resources.cf01;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            // 
            // frmBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 413);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmBanHang";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmBanHang_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoUong)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabDoUong.ResumeLayout(false);
            this.tabDoUong.PerformLayout();
            this.grTaoMoiDoUong.ResumeLayout(false);
            this.grTaoMoiDoUong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDoUong)).EndInit();
            this.tabBanHang.ResumeLayout(false);
            this.pnHoaDon.ResumeLayout(false);
            this.pnHoaDon.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label currentTime;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem account;
        private System.Windows.Forms.ToolStripMenuItem logout;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dgvDoUong;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaDoUong;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenDoUong;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridViewCheckBoxColumn TrangThai;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabDoUong;
        private System.Windows.Forms.RadioButton rdHetHang;
        private System.Windows.Forms.RadioButton rdConHang;
        private System.Windows.Forms.PictureBox pbDoUong;
        private System.Windows.Forms.Button btnXoaDoUong;
        private System.Windows.Forms.Button btnLuuDoUong;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.TextBox txtTenDoUong;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMaDoUong;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnTaoMoiDoUong;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.TabPage tabBanHang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtKW;
        private System.Windows.Forms.ComboBox cbLoaiTimKiem;
        private System.Windows.Forms.GroupBox grTaoMoiDoUong;
        private System.Windows.Forms.Button btnThemHoaDon;
        private System.Windows.Forms.TextBox txtSum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListView listSellItems;
        private System.Windows.Forms.FlowLayoutPanel flpDoUong;
        private System.Windows.Forms.Panel pnHoaDon;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnChonHinh;
    }
}